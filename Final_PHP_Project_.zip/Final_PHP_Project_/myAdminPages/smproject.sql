-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 21, 2018 at 11:31 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.25-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `catId` int(10) UNSIGNED NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`catId`, `name`, `description`) VALUES
(1, 'fashion', 'fashion'),
(2, 'food', 'food'),
(3, 'social', 'social'),
(4, 'Entertainment', 'Entertainment');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comId` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `comment` varchar(1000) NOT NULL,
  `postid` int(11) NOT NULL,
  `commentStatus` varchar(50) NOT NULL,
  `reason` varchar(800) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comId`, `title`, `comment`, `postid`, `commentStatus`, `reason`) VALUES
(1, 'comment1', 'Hi ', 1, 'approved', NULL),
(2, 'comment2', 'Hi', 1, 'Approved', NULL),
(3, 'comment3', 'Hi', 1, 'Approved', NULL),
(4, 'comment4', 'Hi', 1, 'deleted', 'It is not a suitable comment.'),
(5, 'comment5', 'Hi', 1, 'deleted', 'It is not a suitable comment.'),
(6, 'comment6', 'Hi', 1, 'draft', NULL),
(7, 'comment6', 'Hi', 1, 'draft', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `text` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `categoryId` int(10) UNSIGNED NOT NULL,
  `postStatus` varchar(50) NOT NULL,
  `postedBy` int(10) UNSIGNED NOT NULL,
  `postedAt` datetime NOT NULL,
  `postReason` varchar(800) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `name`, `text`, `image`, `categoryId`, `postStatus`, `postedBy`, `postedAt`, `postReason`) VALUES
(1, 'post1', 'post post', NULL, 1, 'approved', 1, '2018-02-19 00:00:00', NULL),
(2, 'post2', 'Hello', NULL, 3, 'draft', 3, '2018-02-19 00:00:00', NULL),
(3, 'post4', 'Achieve your goals. ', NULL, 3, 'approved', 6, '2018-02-19 00:00:00', NULL),
(4, 'post2cat2', 'Post from Egypt.', NULL, 4, 'deleted', 7, '2018-02-19 00:00:00', 'This is not a suitable post.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(60) NOT NULL,
  `firstName` varchar(60) NOT NULL,
  `lastName` varchar(60) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `userStatus` varchar(50) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `deleteReason` varchar(800) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `password`, `userStatus`, `photo`, `deleteReason`) VALUES
(1, 'asmaa', 'Asmaa', 'Ismail', 'asmaaali2017@gmail.com', 'asmaa', 'active', 'index.jpeg', NULL),
(2, 'ali1', 'ali', 'monir', 'ali@gmail.com', '456', 'active', 'index.jpeg', 'This user is impolite.'),
(3, 'Hoda', 'Hoda', '', 'Hoda@gmail.com', '123', 'active', 'index.jpeg', NULL),
(6, 'Samir', 'Samir', 'Mohamed', 'Samir@gmail.com', '789', 'deleted', 'index.jpeg', 'This user is impolite.'),
(7, 'Rana1', 'Rana', 'Khaled', 'Ranaa@gmail.com', 'rana1', 'inactive', 'index.jpeg', 'This user has many aggressive posts and comments.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comId`),
  ADD KEY `postid` (`postid`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoryId` (`categoryId`),
  ADD KEY `postedBy` (`postedBy`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `catId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`postid`) REFERENCES `posts` (`id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`catId`),
  ADD CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`postedBy`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
