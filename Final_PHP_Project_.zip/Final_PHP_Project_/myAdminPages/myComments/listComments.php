<?php

//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$query="select * from comments";
// die($query);
$comments = mysqli_query($con,$query);
//3- check result
if(!$comments{
    echo mysqli_error($con)."<br>";
    exit;
}


//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>List</title>
</head>

<body>
   <h2>List of comments</h2>
   <table>
       <tr>
           <th>comId</th>
           <th>title</th>
           <th>comment</th>
           <th>postid</th>
           <th>commentStatus</th>
           <th>reason</th>
       </tr>
        <?php
            while ($comment = mysqli_fetch_assoc($comments)) {
               ?>
                <tr>
                    <td><?= $comment['comId'] ?></td>
                    <td><?= $comment['title'] ?></td>
                    <td><?= $comment['comment'] ?></td>
                    <td><?= $comment['postid'] ?></td>
                    <td><?= $comment['commentStatus'] ?></td>
                    <td><?= $comment['reason'] ?></td>

                    <td>
                        <a href="editComment.php?comId=<?= $comment['comId']?>">edit</a>
                        <a href="deleteComment.php?comId=<?= $comment['comId'] ?>">delete</a>
                    </td>
                </tr>
               <?php
            }
        ?>
   </table>
   <a href="index.php">Register</a>
</body>
</html>
