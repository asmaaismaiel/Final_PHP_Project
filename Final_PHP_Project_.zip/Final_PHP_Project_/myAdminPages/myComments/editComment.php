<?php
require 'commentsClass.php';
$comId=$_GET['comId'];
//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
$comment= Comments::getCommentByID($con,$comId);
// print_r($comment);
// exit;

//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit comment</title>
</head>
<body>
    <form action="updateComment.php?id=<?= $comment->comId ?>" method="post">
        <label for="title">Title:</label>
        <input type="text" name="title" value="<?= $comment->title ?>"><br>

        <label for="comment">comment:</label>
        <input type="text" name="comment" value="<?= $comment->comment ?>"><br>

        <label for="postid">postid:</label>
        <input type="text" name="postid" value="<?= $comment->postid ?>"><br>

        <label for="commentStatus">commentStatus :</label>
        <input type="text" name="commentStatus" value="<?= $comment->commentStatus ?>"><br>

        <label for="reason">reason :</label>
        <input type="text" name="reason" value="<?= $comment->reason ?>"><br>

        <input type="submit" name="Update" value="Update">

    </form>
</body>
</html>
