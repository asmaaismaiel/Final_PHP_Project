<?php
class Comments{
    private $comId;
    private $title;
    private $comment;
    private $postid;
    private $commentStatus;
    private $reason;

    function __construct($title,$comment,$postid,$commentStatus,$reason,$comId=NULL){
        $this->comId=$comId;
        $this->title=$title;
        $this->comment=$comment;
        $this->postid=$postid;
        $this->commentStatus=$commentStatus;
        $this->reason=$reason;
    }

    function __set($attr, $value){
        $this->$attr=$value;
    }

    function __get($attr){
        return $this->$attr;
    }

    //insert
    function insert($con){
        $query="INSERT INTO comments values(
            NULL,
            '$this->title',
            '$this->comment',
            '$this->postid',
            '$this->commentStatus',
            '$this->reason'
        )";
        // die($query);
        $result = mysqli_query($con,$query);
         //3- check result
        if(!$result){
            echo mysqli_error($con)."<br>";
            return false;
        }
        else{
            return true;
        }
    }

    // delete
    static function delete($con,$comId){
        $result=true;
        $query="DELETE from comments where comId=$comId";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result|| !mysqli_affected_rows($con)>0){
                echo mysqli_error($con);
                $result= false;
            }
        return $result;
    }

    // getUserByID
    static function getCommentByID($con,$comId){
        $result=false;
        $query="SELECT * from comments where comId=$comId LIMIT 1";
        // die($query);
        $result = mysqli_query($con,$query);
        $comment = mysqli_fetch_assoc($result);
        if($comment){
            $result= new Comments(
                $comment['title'],
                $comment['comment'],
                $comment['postid'],
                $comment['commentStatus'],
                $comment['reason']
            );
        }
        return $result;
    }

    //Update
    function update($con){
        $result = true;
        $query="UPDATE  Comments set
        title='$this->title',
        comment='$this->comment',
        postid='$this->postid',
        commentStatus='$this->commentStatus',
        reason='$this->reason'
        where comId=$this->comId";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result||!mysqli_affected_rows($con)>0){
                $result = false;
            }
            return $result;
        }
}

?>
