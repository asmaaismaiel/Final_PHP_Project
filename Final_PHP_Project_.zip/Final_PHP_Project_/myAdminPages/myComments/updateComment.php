<?php
require_once 'commentsClass.php';

ob_start();
$comId=$_GET['comId'];


$title = $_POST['title'];
$comment = $_POST['comment'];
$postid = $_POST['postid'];
$commentStatus = $_POST['commentStatus'];
$reason = $_POST['reason'];

//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$comment=new Comments($title,$comment,$postid,$commentStatus,$reason,$comId);
$result = $comId->update($con);
if(!$result){
    $message='not updated';
}else{
    $message="updated";
}

//4- close connection
mysqli_close($con);
header("Location: listComments.php?message=$message");

?>
