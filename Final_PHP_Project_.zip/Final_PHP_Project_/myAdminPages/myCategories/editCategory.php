<?php
require 'categoriesClass.php';
$catId=$_GET['catId'];
//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
$category= Categories::getCategoryByID($con,$catId);
// print_r($student);
// exit;

//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit category</title>
</head>
<body>
    <form action="updateCategory.php?catId=<?= $category->catId ?>" method="post">
        <label for="name">name:</label>
        <input type="text" name="name" value="<?= $category->name ?>"><br>
        <label for="description">description:</label>
        <input type="text" name="description" value="<?= $category->description ?>"><br>

        <input type="submit" name="Update" value="Update">

    </form>
</body>
</html>
