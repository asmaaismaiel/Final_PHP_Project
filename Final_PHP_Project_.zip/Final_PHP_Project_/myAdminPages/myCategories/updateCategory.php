<?php
require_once 'categoriesClass.php';

ob_start();
$catId=$_GET['catId'];

$name = $_POST['name'];
$description= $_POST['description'];



//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
$category=new Categories($name,$description,$catId);

// echo "connection success<br>";
//2- insert student
//$category=new Categories($name,$description,$catId);
$result = $category->update($con);
if(!$result){
    $message='not updated';
}else{
    $message="updated";
}

//4- close connection
mysqli_close($con);
header("Location: listCategory.php?message=$message");

?>
