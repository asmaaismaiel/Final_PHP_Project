<?php
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$query="select * from categories";
// die($query);
$categories = mysqli_query($con,$query);
//3- check result
if(!$categories){
    echo mysqli_error($con)."<br>";
    exit;
}


//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>List</title>
</head>

<body>
   <h2>List of categories</h2>
   <table>
       <tr>
         <th>Title</th>
         <th>description</th>
       </tr>
        <?php
            while ($category = mysqli_fetch_assoc($categories)) {
               ?>
                <tr>
                  <td><?= $category['name']?></td>
                  <td><?= $category['description']?></td>

                    <td>
                        <a href="editCategory.php?catId=<?= $category['catId']?>">edit</a>
                        <a href="deleteCategory.php?catId=<?= $category['catId']?>">delete</a>
                    </td>
                </tr>
               <?php
            }
        ?>
   </table>
   <a href="index.php">Go to home page</a>
</body>
</html>
