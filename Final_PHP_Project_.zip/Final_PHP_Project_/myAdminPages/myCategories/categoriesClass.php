<?php
class Categories{
    private $catId;
    private $name;
    private $description;


    function __construct($name,$description,$catId=NULL)
    {
        $this->catId=$catId;
        $this->name=$name;
        $this->description=$description;





    }

    function __set($attr, $value){
        $this->$attr=$value;
    }

    function __get($attr){
        return $this->$attr;
    }

    //insert
    function insert($con){
        $query="INSERT INTO categories values(
            NULL,
            '$this->name',
            '$this->description'

        )";
        // die($query);
        $result = mysqli_query($con,$query);
         //3- check result
        if(!$result){
            echo mysqli_error($con)."<br>";
            return false;
        }
        else{
            return true;
        }
    }

    // delete




     static function delete($con,$catId){
        $result=true;
        $query="DELETE from categories where catId=$catId";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result|| !mysqli_affected_rows($con)>0){
                echo mysqli_error($con);
                $result= false;
            }
        return $result;
    }



 function getAllCategories($con){
    $result=false;
    $query="SELECT * from categories";
    // die($query);
    $result = mysqli_query($con,$query);
    $category = mysqli_fetch_assoc($result);
    if($category){
        $result= new Categories(
          $category['catId'],
          $category['name'],
          $category['description']
        );
    }
    return $result;
}

    // getPostByID
     static function getCategoryByID($con,$catId){
        $result=false;
        $query="SELECT * from categories where catId=$catId LIMIT 1";
        // die($query);
        $result = mysqli_query($con,$query);
        $category = mysqli_fetch_assoc($result);
        if($category){
            $result= new Categories(
              $category['catId'],
              $category['name'],
              $category['description']
            );
        }
        return $result;
    }



    function update($con){
        $result = true;
        $query="UPDATE categories set
        catId='$this->catId',
        name='$this->name',
        description='$this->description'
        where catId=$this->catId";

        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result||!mysqli_affected_rows($con)>0){
            $result = false;
            }
            return $result;
        }
}

?>
