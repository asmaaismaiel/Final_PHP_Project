<?php
require_once 'categoriesClass.php';

$catId=$_GET['catId'];
//1- connect to db

//private $catId;
//private $name;
//private $description;
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student


if(!Categories::delete($con,$catId)){
    $message='not deleted';
}else{
    $message="deleted";
}

//4- close connection
mysqli_close($con);
header("Location: listCategory.php?message=$message");

?>
