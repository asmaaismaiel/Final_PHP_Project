<?php
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$query="select * from users";
// die($query);
$users = mysqli_query($con,$query);
//3- check result
if(!$users){
    echo mysqli_error($con)."<br>";
    exit;
}
/*username='$this->username',
firstName='$this->firstName',
lastName='$this->lastName',
email='$this->email',
password='$this->password',
userStatus='$this->userStatus',
photo='$this->photo',
deleteReason='$this->deleteReason'*/

//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>List</title>
</head>

<body>
   <h2>List of users</h2>
   <table>
       <tr>
         <th>username</th>
         <th>firstName</th>
         <th>lastName</th>
         <th>email</th>
         <th>password</th>
         <th>userStatus</th>
         <th>photo</th>
         <th>deleteReason</th>
       </tr>
        <?php
            while ($user = mysqli_fetch_assoc($users)) {
               ?>
                <tr>
                  <td><?= $user['username']?></td>
                  <td><?= $user['firstName']?></td>
                  <td><?= $user['lastName']?></td>
                  <td><?= $user['email']?></td>
                  <td><?= $user['password']?></td>
                  <td><?= $user['userStatus']?></td>
                  <td><?= $user['photo']?></td>
                  <td><?= $user['deleteReason']?></td>

                    <td>
                        <a href="editUser.php?id=<?= $user['id']?>">edit</a>
                        <a href="deleteUser.php?id=<?= $user['id']?>">delete</a>
                    </td>
                </tr>
               <?php
            }
        ?>
   </table>
   <a href="index.php">Go to home page</a>
</body>
</html>
