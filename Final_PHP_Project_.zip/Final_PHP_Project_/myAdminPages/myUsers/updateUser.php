<?php
require_once 'usersClass.php';

ob_start();
$id=$_GET['id'];
/*username='$this->username',
firstName='$this->firstName',
lastName='$this->lastName',
email='$this->email',
password='$this->password',
userStatus='$this->userStatus',
photo='$this->photo',
deleteReason='$this->deleteReason'*/

$username= $_POST['username'];
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];
$password = $_POST['password'];
$userStatus = $_POST['userStatus'];
$photo = $_POST['photo'];
$deleteReason = $_POST['deleteReason'];

//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$user=new Users($name,$email,$password,$id);
$result = $user->update($con);
if(!$result){
    $message='not updated';
}else{
    $message="updated";
}

//4- close connection
mysqli_close($con);
header("Location: listUsers.php?message=$message");

?>
