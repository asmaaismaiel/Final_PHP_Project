<?php
require 'usersClass.php';
$id=$_GET['id'];
//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
$user= Users::getUserByID(($con,$id);
// print_r($student);
// exit;

//4- close connection
/*$id;
private $username;
private $firstName;
private $lastName;
private $email;
private $password;
private $userStatus;
private $photo;
private $deleteReason;*/
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit User</title>
</head>
<body>
    <form action="updateUser.php?id=<?= $user->id ?>" method="post">
        <label for="name">username:</label>
        <input type="text" name="name" value="<?= $user->username ?>"><br>
        <label for="firstName">firstName:</label>
        <input type="text" name="firstName" value="<?= $user->firstName ?>"><br>
        <label for="lastName">lastName:</label>
        <input type="text" name="lastName" value="<?= $user->lastName ?>"><br>
        <label for="email">email:</label>
        <input type="text" name="email" value="<?= $user->email ?>"><br>
        <label for="password">password:</label>
        <input type="password" name="password" value="<?= $user->password ?>"><br>
        <label for="userStatus">userStatus:</label>
        <input type="text" name="userStatus" value="<?= $user->userStatus ?>"><br>
        <label for="photo">photo:</label>
        <input type="text" name="photo" value="<?= $user->photo?>"><br>
        <label for="deleteReason">deleteReason:</label>
        <input type="text" name="deleteReason" value="<?= $user->deleteReason ?>"><br>

        <input type="submit" name="Update" value="Update">

    </form>
</body>
</html>
