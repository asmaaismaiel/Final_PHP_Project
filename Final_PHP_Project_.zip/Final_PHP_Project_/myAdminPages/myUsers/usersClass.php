<?php
class Users{
    private $id;
    private $username;
    private $firstName;
    private $lastName;
    private $email;
    private $password;
    private $userStatus;
    private $photo;
    private $deleteReason;

    function __construct($username, $firstName, $lastName,$email,$password,$userStatus,$photo,$deleteReason,$id=NULL){
        $this->id=$id;
        $this->username=$username;
        $this->firstName=$firstName;
        $this->lastName=$lastName;
        $this->email=$email;
        $this->$password=$password;
        $this->$userStatus=$userStatus;
        $this->photo=$photo;
        $this->deleteReason=$deleteReason;
    }

    function __set($attr, $value){
        $this->$attr=$value;
    }

    function __get($attr){
        return $this->$attr;
    }

    //insert
    function insert($con){
        $query="INSERT INTO users values(
            NULL,
            '$this->username',
            '$this->firstName',
            '$this->lastName',
            '$this->email',
            '$this->password',
            '$this->$userStatus',
            '$this->photo',
            '$this->deleteReason'
        )";
        // die($query);
        $result = mysqli_query($con,$query);
         //3- check result
        if(!$result){
            echo mysqli_error($con)."<br>";
            return false;
        }
        else{
            return true;
        }
    }

    // delete
    static function delete($con,$id){
        $result=true;
        $query="UPDATE users set userStatus='deleted' where id=$id";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result|| !mysqli_affected_rows($con)>0){
                echo mysqli_error($con);
                $result= false;
            }
        return $result;
    }

    // getUserByID
    static function getUserByID($con,$id){
        $result=false;
        $query="SELECT * from users where id=$id LIMIT 1";
        // die($query);
        $result = mysqli_query($con,$query);
        $user = mysqli_fetch_assoc($result);
        if($user){
            $result= new Users(
                $user['username'],
                $user['firstName'],
                $user['lastName'],
                $user['email'],
                $user['password'],
                $user['userStatus'],
                $user['photo'],
                $user['deleteReason'],
                $user['id']
            );
        }
        return $result;
    }

    //Update
    function update($con){
        $result = true;
        $query="UPDATE users set
        username='$this->username',
        firstName='$this->firstName',
        lastName='$this->lastName',
        email='$this->email',
        password='$this->password',
        userStatus='$this->userStatus',
        photo='$this->photo',
        deleteReason='$this->deleteReason'
        where id=$this->id";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result||!mysqli_affected_rows($con)>0){
                $result = false;
            }
            return $result;
        }
}

?>
