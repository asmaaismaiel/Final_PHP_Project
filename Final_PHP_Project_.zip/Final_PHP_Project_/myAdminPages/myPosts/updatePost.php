<?php
require_once 'postsClass.php';

ob_start();
$id=$_GET['id'];

/* $id,
 $postStatus,
 $categoryId,
 $postContent,
 $postedBy,
 $postedAt,
 $postTitle,
 $image*/

 $id= $_POST['id'];
 $name= $_POST['name'];
 $text= $_POST['text'];
 $image= $_POST['image'];
 $categoryId= $_POST['categoryId'];
 $postStatus= $_POST['postStatus'];
 $postedBy= $_POST['postedBy'];
 $postedAt= $_POST['postedAt'];
$postReason=$_POST['postReason'];




//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$post=new Posts($categoryId,$text,$name,$postedBy,$postedAt,$postStatus,$image,$postReason,$id)

$result = $post->update($con);
if(!$result){
    $message='not updated';
}else{
    $message="updated";
}

//4- close connection
mysqli_close($con);
header("Location: listPost.php?message=$message");

?>
