<?php
class Posts{
    private $id;
    private $name;
    private $text;
    private $image;
    private $categoryId;
    private $postStatus;
    private $postedBy;
    private $postedAt;
    private $postReason;


    function __construct($name,$text,$image,$categoryId,$postStatus,$postedBy,$postedAt,$postReason,$id=NULL){
        $this->$id=$id;
        $this->$name=$name;
        $this->text=$text;
        $this->$image=$image;
        $this->categoryId=$categoryId;
        $this->postStatus=$postStatus;
        $this->postedBy=$postedBy;
        $this->postedAt=$postedAt;
        $this->postReason=$postReason;


    }

    function __set($attr, $value){
        $this->$attr=$value;
    }

    function __get($attr){
        return $this->$attr;
    }

    //insert
    function insert($con){
        $query="INSERT INTO posts values(
            NULL,
            '$this->$name',
            '$this->text',
            '$this->$image',
            '$this->categoryId',
            '$this->postStatus',
            '$this->postedBy',
            '$this->postedAt',
            '$this->postReason'
        )";
        // die($query);
        $result = mysqli_query($con,$query);
         //3- check result
        if(!$result){
            echo mysqli_error($con)."<br>";
            return false;
        }
        else{
            return true;
        }
    }

    // delete
    static function delete($con,$id){
        $result=true;
        $query="UPDATE posts set postStatus='deleted' where id=$this->id";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result|| !mysqli_affected_rows($con)>0){
                echo mysqli_error($con);
                $result= false;
            }
        return $result;
    }

/*
$post['postId'] ?></td>
<td><?= $post['categoryId'] ?></td>
<td><?= $post['postContent'] ?></td>
<td><?= $post['postedBy'] ?></td>
<td><?= $post['postedAt'] ?></td>
<td><?= $post['postStatus'] ?></td>
<td><?= $post['coverPhoto']
*/


static function getAllPosts($con){
    $result=false;
    $query="SELECT * from posts LIMIT 10 order by postedAt desc";
    // die($query);
    $result = mysqli_query($con,$query);
    $post = mysqli_fetch_assoc($result);
    if($post){
        $result= new Posts(
          $post['categoryId'],
          $post['text'],
          $post['name'],
          $post['postedBy'],
          $post['postedAt'],
          $post['postStatus'],
          $post['image'],
          $post['postReason'],
          $post['id']
        );
    }
    return $result;
}

    // getPostByID
    static function getPostByID($con,$id){
        $result=false;
        $query="SELECT * from posts where id=$this->id LIMIT 10";
        // die($query);
        $result = mysqli_query($con,$query);
        $post = mysqli_fetch_assoc($result);
        if($post){
            $result= new Posts(
              $post['categoryId'],
              $post['text'],
              $post['name'],
              $post['postedBy'],
              $post['postedAt'],
              $post['postStatus'],
              $post['postedBy'],
              $post['postedAt'],
              $post['image'],
              $post['postReason'],
              $post['id']
            );
        }
        return $result;
    }



    function update($con){
        $flag = true;
        $query="UPDATE posts set
        categoryId='$this->categoryId',
        text='$this->text',
        name='$this->name',
        postedBy='$this->postedBy',
        postedAt='$this->postedAt',
        postStatus='$this->postStatus',
        postedBy='$this->postedBy,
        postedAt='$this->postedAt',
        image='$this->image',
        postReason='$this->postReason'
        where id=$this->id";

        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result||!mysqli_affected_rows($con)>0){
            $flag = false;
            }
            return $result;
        }
}

?>
