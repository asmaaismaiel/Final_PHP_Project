<?php
require 'postsClass.php';
//$id=$_GET['id'];
$id=$_GET['id'];
//1- connect to db
$con = mysqli_connect('localhost','root','asmaa','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
$post= Posts::getPostByID($con,$id);
// print_r($student);
// exit;

//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit POst</title>
</head>
<body>
    <form action="updatePost.php?id=<?= $post->id ?>" method="post">
        <label for="name">name:</label>
        <input type="text name="name" value="<?= $post-> 	categoryId ?>"><br>
        <label for="text">postContent:</label>
        <textarea name="text" value="<?=$post->text?>"></textarea><br>
          <label for="categoryId">categoryId:</label>
          <input type="text" name="categoryId" value="<?= $post-> 	categoryId ?>"><br>
        <label for="postStatus">postStatus:</label>
        <input type="text" name="postStatus" value="<?= $post->postStatus ?>"><br>


        <label for="postedBy">postedBy:</label>
        <input type="text" name="postedBy" value="<?= $post->postedBy ?>"><br>
        <label for="postedAt">postedAt:</label>
        <input type="text" name="postedAt" value="<?= $post->postedAt ?>"><br>
        <label for="postReason">postReason:</label>
        <input type="text" name="postReason" value="<?= $post->postReason ?>"><br>

        <input type="submit" name="Update" value="Update">

    </form>
</body>
</html>
