<?php
class User extends ActiveRecord\Model{

    private $name;
    private $email;
    private $password;

}

    ?>
