<?php

class Post extends ActiveRecord\model
{
    private $id;
     private $name;
     private $text;
     private $image;
}








 ?>
