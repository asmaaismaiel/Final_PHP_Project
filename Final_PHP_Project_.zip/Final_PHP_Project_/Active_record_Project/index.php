<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Home</title>

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">

	<link rel="stylesheet" href="css/style.css"/>

</head>
<body>

 <div class="container">
      <h1 class="text-center primary">WELCOME</h1>
      <form action="login.php" method="post">
      <div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
    <input id="name" type="text" class="form-control" name="name" placeholder="name" required>
    </div><br>
    <div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
    <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
    </div><br>

    <Button class="btn btn-success">Log In</Button>


        </form>



      <h1 class="text-center">Registration</h1>
      <form action="signup.php" name="registration" method="post" >

        <label for="newname">Your Name</label>
        <input type="text" name="fullname" id="firstname" placeholder="John"/>

        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="john@doe.com"/>

        <label for="password">Password</label>
        <input type="password" name="newpassword" id="password" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;"/>

        <button type="submit" class="btn btn-info" name="register" value="Register">Register</button>

      </form>
</div>
  <script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js
"></script>
<script type="text/javascript" src="js/fom.js" ></script>
</html>
