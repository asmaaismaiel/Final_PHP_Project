-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 21, 2018 at 07:00 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.25-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `catId` int(10) UNSIGNED NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `description` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`catId`, `name`, `description`) VALUES
(1, 'fashion', 'fashion'),
(2, 'food', 'food'),
(3, 'social', 'social'),
(4, 'social', 'social');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comId` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `comment` varchar(1000) NOT NULL,
  `postid` int(11) NOT NULL,
  `postStatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comId`, `title`, `comment`, `postid`, `postStatus`) VALUES
(1, 'comment1', 'comment 1 comment 1 comment 1 comment 1 comment 1 comment 1 ', 1, 'not'),
(2, 'comment 2', 'comment 2 comment 2 comment 2 comment 2', 1, 'approv'),
(3, 'bb', 'bb', 1, 'not'),
(4, 'tttttt', 'cccccc', 1, 'approved'),
(5, 'sssss', 'ccccccccccccc', 1, 'notApproved'),
(6, 'sssss', 'ccccccccccccc', 1, 'notApproved'),
(7, 'sssss', 'ccccccccccccc', 1, 'notApproved'),
(8, 'sssss', 'ccccccccccccc', 1, 'notApproved'),
(9, 'lol', 'lol lol', 1, 'notApproved'),
(10, 'lol', 'lol lol', 1, 'notApproved'),
(11, 'not', 'not not', 1, 'notApproved'),
(12, '', '', 1, 'draft'),
(13, 'sss', 'ddfdddddd', 1, 'draft'),
(14, 'gggg', 'ggggggg', 5, 'draft'),
(15, 'ggt', 'tttttttttt', 5, 'draft');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `categoryId` int(10) UNSIGNED NOT NULL,
  `postStatus` varchar(50) NOT NULL,
  `postedBy` int(10) UNSIGNED DEFAULT NULL,
  `postedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `name`, `text`, `image`, `categoryId`, `postStatus`, `postedBy`, `postedAt`) VALUES
(1, 'post1', 'post post', NULL, 1, 'approved', 1, '2018-02-19 00:00:00'),
(2, 'post2cat1', 'post2cat1 post2cat1 post2cat1 post2cat1 post2cat1', NULL, 1, 'approved', 1, '2018-02-19 00:00:00'),
(3, 'post3cat1', 'post3cat1post3cat1 post3cat1 post3cat1', NULL, 1, 'approved', 2, '2018-02-19 00:00:00'),
(4, 'post1cat2', 'post1cat2post1cat2post1cat2post1cat2', NULL, 2, 'approved', 1, '2018-02-19 00:00:00'),
(5, 'post2cat2', 'post2cat2 post2cat2 post2cat2post2cat2', NULL, 2, 'approved', 2, '2018-02-19 00:00:00'),
(6, 'first', 'food first', '1518998756151899843215189972241518988840151898500415189646201518962988151852567527657974_2028315454110757_8064556067388805727_n.jpg', 2, 'draft', NULL, NULL),
(7, 'first', 'food first', '1518998756151899843215189972241518988840151898500415189646201518962988151852567527657974_2028315454110757_8064556067388805727_n.jpg', 2, 'draft', NULL, NULL),
(8, 'hhhhh', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', '1518998756151899843215189972241518988840151898500415189646201518962988151852567527657974_2028315454110757_8064556067388805727_n.jpg', 2, 'draft', NULL, NULL),
(9, 'hhhhh', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', '1518998756151899843215189972241518988840151898500415189646201518962988151852567527657974_2028315454110757_8064556067388805727_n.jpg', 2, 'draft', NULL, NULL),
(10, 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', '1518998756151899843215189972241518988840151898500415189646201518962988151852567527657974_2028315454110757_8064556067388805727_n.jpg', 2, 'draft', NULL, NULL),
(11, 'frfff', 'fffffff', '', 1, 'draft', NULL, NULL),
(12, 'test time', 'test time test time', '', 3, 'draft ', NULL, NULL),
(13, 'welcome', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', '', 1, 'draft ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(60) NOT NULL,
  `firstName` varchar(60) DEFAULT NULL,
  `lastName` varchar(60) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `photo` varchar(255) DEFAULT 'min.jpg',
  `password` varchar(30) NOT NULL,
  `userStatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `photo`, `password`, `userStatus`) VALUES
(1, 'alaaDiab', 'hhhhhhhhhhhhhhhhh', 'diab', 'alaa@gmail.com', '15192322581518998756151899843215189972241518988840151898500415189646201518962988151852567527657974_2028315454110757_8064556067388805727_n.jpg', '123', 'active'),
(2, 'bsbs', 'bs', 'bs', 'bs@gmail.com', '1519148917', '123', 'active'),
(3, 'bla bla ', 'ssss', '', 'ss@gmail.com', 'min.jpg', '0', 'inactive'),
(6, 'qqqq', NULL, NULL, 'q@gmail.com', 'min.jpg', '123', 'inactive'),
(7, 'bl7a', NULL, NULL, 'bl7a@a.com', 'min.jpg', '123', 'inactive');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comId`),
  ADD KEY `postid` (`postid`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoryId` (`categoryId`),
  ADD KEY `postedBy` (`postedBy`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `catId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`postid`) REFERENCES `posts` (`id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`catId`),
  ADD CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`postedBy`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
