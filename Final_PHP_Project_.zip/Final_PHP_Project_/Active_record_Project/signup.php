<?php
require_once 'config.php';
require_once 'vendor/php-activerecord/php-activerecord/ActiveRecord.php';

// $dsn    = 'mysql:host=localhost;dbname=smproject';  //data source name
//  $user   = 'root';
//  $pass   = '12345';
//  $option = array(
//  		PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' //to write in arabic
//  	);
 // try{
 // 	$connect = new PDO($dsn,$user,$pass);
 // 	$connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
 //
 //    }
 //    catch(PDOException $e){
	// 	echo "error".$e->getMessage();
 //    }




 if(isset($_POST['register'])){
     $errors=[];
 $valid=true;


    $name = $_POST['fullname'];
    $email = $_POST['email'];
	 $password = $_POST['newpassword'];
   if($valid){

   $password=password_hash($password, PASSWORD_DEFAULT);




	// $q= "insert into users(name,email,password)values('$name','$email','$newpassword')";
	// $connect->exec($q);
	// echo "DATA added succesfully";
	// include 'index.php';

  $user=new User();
  $user->name=$name;
  $user->email=$email;
  $user->password=$password;

  if($user->save()){
          header('Location: index.php');
      } else{
          header('Location: index.php');
      }
}
}
 ?>
