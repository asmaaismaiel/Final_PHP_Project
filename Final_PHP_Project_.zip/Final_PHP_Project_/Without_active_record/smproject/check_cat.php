<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

if(!isset($_SESSION['id'])){
 
  header('location:index.php ');
}

else{
// start content
 //1- connect to db
 $con = mysqli_connect('localhost','root','000000','smproject');
 if(mysqli_connect_errno()){
     echo mysqli_connect_error()."<br>";
     exit;
 }
 // echo "connection success<br>";
 //2- insert student
 $query="select * from categories";
 // die($query);
 $categories = mysqli_query($con,$query);
 //3- check result
 if(!$categories){
     echo mysqli_error($con)."<br>";
     exit;
 }
 

 
 
 //4- close connection
 mysqli_close($con);





}
?>