<?php
class categories{
    private $id;
    private $userName;
    private $firstName;
    private $lastName;
    private $email;
    private $password;
    private $userStatus;
    private $photo;
   

    function __construct($username, $firstName,$lastName,$email,$password,$userStatus,$photo,$idd=NULL){
        $this->id=$id;
        $this->username=$username;
        $this->firstName=$firstName;
        $this->lastName=$lastName;
        $this->email=$email;
        $this->password=$password;
        $this->userStatus=$userStatus;
        $this->photo=$photo;


      }

    function __set($attr, $value){
        $this->$attr=$value;
    }

    function __get($attr){
        return $this->$attr;
    }

    //insert
    function insert($con){
        $query="
          --INSERT INTO `users` (`id`,`username`,`firstName`,`lastName`,`email`, `password`,`userStatus`,`photo`) VALUES
(1,'ayanabil','aya',,'aya@yahoo.com', 123),
('asmaaismel', 'asmaa@yahoo.com', 0),
('asmaaismel', 'asmaa@yahoo.com', 0),
('iam', 'iam@yahoo.com', 123456),
('sayed', 'sayed@yahoo.com', 123456),
('aya', 'aya@gmail.com', 1234);
            
        )";



     
        // die($query);
        $result = mysqli_query($con,$query);
         //3- check result
        if(!$result){
            echo mysqli_error($con)."<br>";
            return false;
        }
        else{
            return true;
        }
    }

    // delete
    static function delete($con,$id){
        $result=true;
        $query="DELETE from categories where id=$id";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result|| !mysqli_affected_rows($con)>0){
                echo mysqli_error($con);
                $result= false;
            }
        return $result;
    }

    // getUserByID
    static function getUserByID($con,$id){
        $result=false;
        $query="SELECT * from users where id=$id LIMIT 1";
        // die($query);
        $result = mysqli_query($con,$query);
        $student = mysqli_fetch_assoc($result);
        if($student){
            $result= new user(
                $user['id'],
                $user['userName'],
                $user['firstName'],
                $user['lastName'],
                $user['email'],
                $user['password'],
                $user['userStatus'],
                $user['photo'],

                
            );
        }
        return $result;
    }

    //Update
    function update($con){
        $result = true;
        $query="UPDATE  users set
        userName='$this->userName',
        description='$this->description'
        where id=$this->id";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result||!mysqli_affected_rows($con)>0){
                $result = false;
            }
            return $result;
        }
}

?>