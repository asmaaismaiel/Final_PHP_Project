



<?php

//1- connect to db
$con = mysqli_connect('localhost','root','000000','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert user
$query="select * from users";
// die($query);
$categories = mysqli_query($con,$query);
//3- check result
if(!$categories){
    echo mysqli_error($con)."<br>";
    exit;
}


//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>List</title>
</head>

<body>
   <h2>List of categories</h2>
   <table>
       <tr>
          <th>ID</th>
          <th>USERName</th>
          <th>FIRSTNAME</th>
          <th>LASTNAME</th>
          <th>EMAIL</th>
          <th>PASSWORD</th>
          <th>USERSTSTUS</th>
          <th>PHOTO</th>
           
           
       </tr>
        <?php
            while ($user = mysqli_fetch_assoc($users)) {
               ?>
                <tr>

                    <td><?= $user['id'] ?></td>
                     <td><?= $user['userName'] ?></td>
                    <td><?= $user['firstName'] ?></td>
                    <td><?= $user['lastName'] ?></td>
                     <td><?= $user['email'] ?></td>
                      <td><?= $user['password'] ?></td>
                       <td><?= $user['userStatus'] ?></td>
                        <td><?= $user['photo'] ?></td>
                        
                  


                    <td>
                        <a href="editusers.php?id=<?= $user['id']?>">edit</a>
                        <a href="deleteusers.php?id=<?= $user['id'] ?>">delete</a>
                    </td>
                </tr>
               <?php
            }
        ?>
   </table>
   <a href="welcome.php">welcome</a>
</body>
</html>