<?php
require 'users.php';
$id=$_GET['id'];
//1- connect to db
$con = mysqli_connect('localhost','root','000000','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
$user= user::getUserByID($con,$id);


//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up</title>
</head>
<body>
    <form action="updateusesr.php?id=<?= $user->id ?>" method="post">
        <label for="id">id:</label>
        <input type="text" name="name" value="<?= $user->id ?>"><br>
        <label for="name">username:</label>
        <input type="name" name="name" value="<?= $user->userName ?>"><br>
        <label for="description">firstName:</label>
        <input type="text" name="firstName" value="<?= $user->firstName ?>"><br>
        <label for="lastName">lastName:</label>
        <input type="name" name="lastName" value="<?= $user->lastName ?>"><br>
        <label for="email">email:</label>
        <input type="name" name="email" value="<?= $user->email ?>"><br>
        <label for="password">password:</label>
        <input type="password" name="password" value="<?= $user->password ?>"><br>
        <label for="userStatus">userStatus:</label>
        <input type="name" name="userStatus" value="<?= $user->userStatus ?>"><br>
        <label for="photo">photo:</label>
        <input type="file" name="photo" value="<?= $user->photo ?>"><br>

        <input type="submit" name="Update" value="Update">

    </form>
</body>
</html>