<?php
require_once 'users.php';

ob_start();
$id=$_GET['id'];



$id=$_POST['id'];
$userName=$_POST['userName'];
$firstName=$_POST['firstName'];
$lastName=$_POST['lastName'];
$email=$_POST['email'];
$password=$_POST['password'];
$userStatus=$_POST['userStatus'];
$photo=$_POST['photo'];

        

//1- connect to db
$con = mysqli_connect('localhost','root','000000','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert user
$category=new user($name,$description,$catId);
$result = $user->update($con);
if(!$result){
    $message='not updated';
}else{
    $message="updated";
}

//4- close connection
mysqli_close($con);
header("Location: list.php?message=$message");

?>