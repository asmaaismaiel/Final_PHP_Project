<?php
require 'category.php';
$id=$_GET['catId'];
//1- connect to db
$con = mysqli_connect('localhost','root','000000','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
$category= category::getategoryByID($con,$catId);


//4- close connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up</title>
</head>
<body>
    <form action="update.php?id=<?= $student->id ?>" method="post">
        <label for="id">id:</label>
        <input type="text" name="name" value="<?= $category->catId ?>"><br>
        <label for="name">name:</label>
        <input type="name" name="name" value="<?= $student->name ?>"><br>
        <label for="description">description:</label>
        <input type="text" name="description" value="<?= $student->description ?>"><br>

        <input type="submit" name="Update" value="Update">

    </form>
</body>
</html>
