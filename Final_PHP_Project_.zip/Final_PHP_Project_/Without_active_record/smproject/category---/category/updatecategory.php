<?php
require_once 'category.php';

ob_start();
$id=$_GET['catId'];


$catId= $_POST['catId'];
$name = $_POST['name'];
$description = $_POST['description'];

//1- connect to db
$con = mysqli_connect('localhost','root','000000','smproject');
if(mysqli_connect_errno()){
    echo mysqli_connect_error()."<br>";
    exit;
}
// echo "connection success<br>";
//2- insert student
$category=new category($name,$description,$catId);
$result = $category->update($con);
if(!$result){
    $message='not updated';
}else{
    $message="updated";
}

//4- close connection
mysqli_close($con);
header("Location: list.php?message=$message");

?>
