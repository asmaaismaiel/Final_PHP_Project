 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Firstname</th><th>Lastname</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'> " . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "000000";
$dbname = "smproject";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id, name, text,image FROM posts");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
?> 


<html>
    <head><title>Products</title>
    <link href="css2/style.css" rel="stylesheet" />
    </head>
    <body>
        <!-- start header -->
        <div id="header">
         <div id="header-container">
                <a href="home.html" id="logo"><img src="img/logo.png" alt="logo" width="50" height="50" /></a>
            
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="products.html">Prouducts</a></li>
                <li><a href="about.html">About us</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="register.html">Register</a></li>
                <li><a href="register.html" class="sign">Login</a></li>
                
            </ul>
          </div>
        </div>
        <!-- end header -->
        
        <!-- start content-->
        <div id="products">
            <div id="content-container">
                
                
               <div class="oneproduct">
                


                 <h1>Title:White Mercedes Benz Cars</h1>

                 <p class="post">
                   bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla 
                  </p>
                 <a href="readmore.html">Read More</a>
               </div>
               
              
               
               
               
               
               
              
               
               
               
               
               
               
               
                
                
                
            </div>
            
        </div>
        
        <!-- start content-->
        
        
        
        <!-- start footer -->
        <div id="footer">
            <div id="footer-container">
            <ul>
                <li><a href="#"><img src="img/fb.png" /></a></li>
                <li><a href="#"><img src="img/g.png" /></a></li>
                <li><a href="#"><img src="img/tw.png" /></a></li>
                <li><a href="#"><img src="img/vimo.png" /></a></li>
            </ul>
            <p>&copy; iti 2017 All Right Reserved</p>
            </div>
        </div>
        <!-- end footer -->
    </body>
</html>