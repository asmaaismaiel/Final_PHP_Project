<?php 
session_start();
if(!isset($_SESSION['id'])){
  echo 'no session';
  header('location:index.php');

}
else{
	
		

require 'check_cat.php';

 ?>


 <?php 

 
require 'check_user_byid.php';       
 
 
		
 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>welcome</title>
	

	<link rel="stylesheet" href="css/style2.css"/>
	<link href="css2/style.css" rel="stylesheet" />

</head>
<body>

<!-- start header -->
<div id="header">
         <div id="header-container">
		 <a href="welcome.php?id=<?=$uid ?>" id="logo"><img src="img/logo.png" alt="logo" width="50" height="50" /></a>
            
            <ul>
                <li><a href="profile.php?id=<?=$uid ?>"><?php echo $student['username']; ?> </a></li>
                
                <li><a href = "out.php" class="sign">Logout</a></li>
                
            </ul>
          </div>
        </div>
        <!-- end header -->

		<div id="content-container">

			<div class="dv1 btn-success">
			
			<div class="col-md-3">
			

			</div>
			
			<div class="one-staff">
			
				<h1 class="titles ">WELCOME</h1>
				<a href="profile.php?id=<?=$uid ?>"><h2> <?php echo $student['firstName'].'  '.$student['lastName']; ?>  </h2></a> 
			</div>
			
			<div >
	
			</div>
			
			


		</div>
		<div class="center_welcome" >
			<div class="myoptions">
				<h1 class="titles">You Options</h1>
				

				    

					<li ><a href="all_posts.php" class="addedPosts">Added post</a></li><br>
					  
					

					 <li ><a href="delete.html" class="addedPosts" > Delete posts</a></li><br>

					 
				


			</div>	

			<div class=" dv3 ">
			<h1 class="titles">Diccuss with the world </h1>
			<form action="posts.php" method="post" >
				<div class="form-group">
					<label for="poster_name">post title</label>
               <input type="text" name="poster_name" class="form-control" id="firstname" placeholder="post title"/>

				</div>
				
                <select name="cats_select" >
				
				<?php 
				while ($caty = mysqli_fetch_assoc($categories)){
				
				?>

				<option value="<?php echo $caty['catId'] ?>" > <?php echo $caty['name'] ?> </option>

				<?php   }  ?>
				
				</select>


                <div class="form-group">
					  <label for="post">YOUR post</label>
					  <textarea class="form-control" rows="5" id="post" name="new_post" placeholder="write your post here" ></textarea>
					</div> 

					<div class="form-group">
					  <label for="image">YOUR photo</label>
					  <input type="file" name="image">

					</div>

					<button class="btn btn-primary btn-lg post_post" >Post</button>


			</form>
				
				
				
				
			</div>

			



		</div>

<!-- start footer -->
<div id="footer">
            <div id="footer-container">
                <h2 class="cats" >Categories</h2>
            <ul class="cat">

            <?php 
				while ($caty = mysqli_fetch_assoc($categories)){
				
				?>

				


                <li><a href="cat.php?cid=<?php echo $caty['catId'] ?> " ><?php echo $caty['name'] ?> </a></li>



			<?php   }  ?>


                
            </ul>
            <p>&copy; iti 2017 All Right Reserved</p>
            </div>
        </div>
        <!-- end footer -->
     
</body>
</html>

<?php

				}
?>