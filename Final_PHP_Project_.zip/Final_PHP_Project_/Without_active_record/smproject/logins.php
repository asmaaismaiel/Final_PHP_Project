<?php 

session_start();
   
if(isset($_SESSION['id'])){
    echo 'no session';
    header('location:welcome.php?id='. $_SESSION['id'].' ');

}
else{
//print_r($_SESSION);

if(isset($_POST['logins'])){

    $name = $_POST['name'];
    $password  = $_POST['password'];

    if($name=='admin'&&$password=='admin'){

        header('location:category---/users/listusers.php');
    }
    else{
  
  
    $con = mysqli_connect('localhost','root','000000','smproject');
    if(mysqli_connect_errno()){
        echo mysqli_connect_error()."<br>";
        exit;
    }
    // echo "connection success<br>";
    //2- insert student
    $query="select * from users where username='$name' and password='$password'  ";
    // die($query);
    $students = mysqli_query($con,$query);
    //3- check result
    if(!$students){
        echo mysqli_error($con)."<br>";
        exit;
    }
    $student=mysqli_fetch_assoc($students);
    $stId=$student['id']; 
    if(mysqli_num_rows($students)==0){
       //echo  mysqli_num_rows($students);
      //echo 'go to login';
       header('location:index.php');    
      // echo"user not found";
    }
    else{
        print_r($student);
       
        // echo 'user name';
        // echo $student['username'];
        // echo 'id';
        // echo $student['id'];
        $_SESSION['id']=$stId;
        // if(!empty($_POST['remember'])){
        //    //echo "yes";
        //    setcookie('user_id', $stId, time() + (60*60*60*70), "/"); 
        //    print_r($_COOKIE);
        // }
        // else{
    
        //     //echo "no";
        // }
        // session_start();
        // $_SESSION['id']=$stId;
      
         header('location:welcome.php?id='.$_SESSION['id'].' '); 
    
    }
    
    
    //4- close connection
    mysqli_close($con);

    






}


}




} //end else


?>