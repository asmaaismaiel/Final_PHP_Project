<?php
class Posts{
    private $postId;
    private $postStatus;
    private $categoryId;
    private $postContent;
    private $postedBy;
    private $postedAt;
    private $postTitle;
    private $image;


    function __construct($postStatus, $categoryId, $postContent,$postedBy,$postedAt,$postTitle,$image,$postId=NULL){
        $this->postId=$postId;
        $this->postStatus=$postStatus;
        $this->categoryId=$categoryId;
        $this->postContent=$postContent;
        $this->postedBy=$postedBy;
        $this->postedAt=$postedAt;
        $this->$postTitle=$postTitle;
        $this->$image=$image;




    }

    function __set($attr, $value){
        $this->$attr=$value;
    }

    function __get($attr){
        return $this->$attr;
    }

    //insert
    function insert($con){
        $query="INSERT INTO posts values(
            NULL,
            '$this->$postTitle',
            '$this->postContent',
            '$this->$image',
            '$this->categoryId',
            '$this->postStatus',
            '$this->postedBy',
            '$this->postedAt'
        )";
        // die($query);
        $result = mysqli_query($con,$query);
         //3- check result
        if(!$result){
            echo mysqli_error($con)."<br>";
            return false;
        }
        else{
            return true;
        }
    }

    // delete
    static function delete($con,$postId){
        $flag=true;
        $query="DELETE from posts where id=$postId";
        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result|| !mysqli_affected_rows($con)>0){
                echo mysqli_error($con);
                $flag= false;
            }
        return $result;
    }

/*
$post['postId'] ?></td>
<td><?= $post['categoryId'] ?></td>
<td><?= $post['postContent'] ?></td>
<td><?= $post['postedBy'] ?></td>
<td><?= $post['postedAt'] ?></td>
<td><?= $post['postStatus'] ?></td>
<td><?= $post['coverPhoto']
*/


static function getAllPosts($con){
    $flag=false;
    $query="SELECT * from posts LIMIT 10 order by postedAt desc";
    // die($query);
    $result = mysqli_query($con,$query);
    $post = mysqli_fetch_assoc($result);
    if($post){
        $result= new Posts(
          $post['categoryId'],
          $post['postText'],
          $post['name'],
          $post['postedBy'],
          $post['postedAt'],
          $post['postStatus'],
          $post['$image'],
          $post['$id']
        );
    }
    return $result;
}

    // getPostByID
    static function getPostByID($con,$postId){
        $flag=false;
        $query="SELECT * from posts where postId=$postId LIMIT 10";
        // die($query);
        $result = mysqli_query($con,$query);
        $post = mysqli_fetch_assoc($result);
        if($post){
            $result= new Posts(
              $post['categoryId'],
              $post['postText'],
              $post['name'],
              $post['postedBy'],
              $post['postedAt'],
              $post['postStatus'],
              $post['$image'],
              $post['$id']
            );
        }
        return $result;
    }


/*  private $postId;
  private $postStatus;
  private $categoryId;
  private $postContent;
  private $postedBy;
  private $postedAt;
  private $postTitle;
  private $image;*/
    //Update
    function update($con){
        $flag = true;
        $query="UPDATE posts set
        categoryId=$this->categoryId,
        postText=$this->postContent,
        postedBy=$this->postedBy,
        postedAt=$this->postedAt,
        postStatus=$this->postStatus,
        image=$this->image,
        name=$this->postTitle,
        where id=$this->postId";

        // die($query);
        $result = mysqli_query($con,$query);
        //3- check result
        if(!$result||!mysqli_affected_rows($con)>0){
            $flag = false;
            }
            return $result;
        }
}

?>
