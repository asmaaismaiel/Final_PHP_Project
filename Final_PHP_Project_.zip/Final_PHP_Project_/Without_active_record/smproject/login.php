<?php 
	
 $dsn    = 'mysql:host=localhost;dbname=smproject';  //data source name 
 $user   = 'root';
 $pass   = '000000';
 $option = array(
 		PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' //to write in arabic 
 	);
 try{
 	$connect = new PDO($dsn,$user,$pass);
 	$connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
 	
    }
    catch(PDOException $e){
		echo "error".$e->getMessage();
    }

    $name = $_POST['name'];
    $password  = $_POST['password'];
    $query  = "select * from users where username = $name and password = $password";

    if ( $query) {
    	
     
    
    require 'welcome.php';
      //echo 'user id';
     //var_dump( $user_exist);
      //header("Location: profile.php?pid= $user_exist['id']");
    }

    else{
    	
      require 'index.php';
      //die;
    }

 ?>
 