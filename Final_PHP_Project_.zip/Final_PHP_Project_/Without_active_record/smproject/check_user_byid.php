<?php 

if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
   

    if(isset($_SESSION['id'])){
   

    $uid=$_SESSION['id'];
   //print_r($_SESSION);
 
 $con = mysqli_connect('localhost','root','000000','smproject');
    if(mysqli_connect_errno()){
        echo mysqli_connect_error()."<br>";
        exit;
    }
    // echo "connection success<br>";
    //2- insert student
    $query="select * from users where id=$uid  ";
    // die($query);
    $students = mysqli_query($con,$query);
    //3- check result
    if(!$students){
        echo mysqli_error($con)."<br>";
        exit;
    }
    $student=mysqli_fetch_assoc($students);
    //$stId=$student['id']; 
    if(mysqli_num_rows($students)==0){
       //echo  mysqli_num_rows($students);
      // echo 'go to login';
       //header('location:login.php');    
	  // echo"user not found";
	  
    }
    else{
        // print_r($student);
       
        // echo 'user name';
        // echo $student['username'];
        // echo 'id';
		// echo $student['id'];
	}



           
           







}

?>